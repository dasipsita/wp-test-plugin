<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://wordpress.org/support/profile/ipsitadas
 * @since      1.0.0
 *
 * @package    Wp_Tp
 * @subpackage Wp_Tp/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
